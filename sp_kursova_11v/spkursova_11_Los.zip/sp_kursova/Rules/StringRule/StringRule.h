#pragma once
#include "stdafx.h"
#include "Controller.h"

BackusRulePtr MakeStringRule(std::shared_ptr<Controller> controller);